package Presentation;

public class testElements {

	public static void main(String[] args) {
/*ControlleurElements controlleurEl=new ControlleurElements();
		
		controlleurEl.demmarrerApplication();*/
		ControlleurElements2 controlleurEl=new ControlleurElements2();
		controlleurEl.demmarrerApplication();

	}

}
