package Presentation;

public class testEntreprise {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ControlleurEntreprise controlleurEntr=new ControlleurEntreprise();
		
		controlleurEntr.demmarrerApplication();
	}

}
