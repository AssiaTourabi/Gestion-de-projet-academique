package Presentation;

public class testprojetDet {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
ControlleurProjetDet controlleurPrD=new ControlleurProjetDet();
		
		//controlleurPrD.demmarrerApplication();
	}

}
