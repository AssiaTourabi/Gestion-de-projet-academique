package Presentation;

import java.awt.HeadlessException;
import java.sql.SQLException;

public class testWelcom {

	public static void main(String[] args) throws HeadlessException, SQLException {
		// TODO Auto-generated method stub
		FenetreWelcom fntrWelc = new FenetreWelcom();

	}

}
