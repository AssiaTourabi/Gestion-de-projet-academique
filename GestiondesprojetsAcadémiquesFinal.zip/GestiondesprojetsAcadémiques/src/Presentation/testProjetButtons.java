package Presentation;

public class testProjetButtons {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
ControlleurProjetButtons controlleurB=new ControlleurProjetButtons ();
		
		//controlleurB.demmarrerApplication();
	}

}
