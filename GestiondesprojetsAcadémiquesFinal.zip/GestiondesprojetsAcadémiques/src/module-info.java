/**
 * 
 */
/**
 * @author oki
 *
 */
module GestiondesprojetsAcadémiques {
	requires java.sql;
	requires java.desktop;
}