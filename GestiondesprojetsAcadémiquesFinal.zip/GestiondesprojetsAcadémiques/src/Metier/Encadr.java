package Metier;

public class Encadr extends professeur {

	public Encadr() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Encadr(String nom_prof, String prenm_prof, String depart_prof, String email_prof, String grade, String Etat,
			String N_somme, String mdp_prof, String fonctionnalite) {
		super(nom_prof, prenm_prof, depart_prof, email_prof, grade, Etat, N_somme, mdp_prof, fonctionnalite);
		// TODO Auto-generated constructor stub
	}

}
